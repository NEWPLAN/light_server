make clean
cd base
make clean
